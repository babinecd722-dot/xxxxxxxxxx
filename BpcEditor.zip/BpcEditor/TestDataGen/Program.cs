using System.IO;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using BpcEditor.Formats;

// ═══════════════════════════════════════════════════════════════════
// Генератор тестового BPC-архива с BTX-текстурами
// Запуск: dotnet run --project TestDataGen
// ═══════════════════════════════════════════════════════════════════

string outputDir = Path.Combine(AppContext.BaseDirectory, "..", "..", "..", "..", "TestData");
Directory.CreateDirectory(outputDir);
string bpcPath = Path.Combine(outputDir, "test_archive.bpc");

var archive = new BpcArchive();

// Создаём несколько BTX-текстур (градиенты)
AddTexture(archive, "textures/red_gradient.btx", 128, 128, CreateGradient(128, 128, Colors.DarkRed, Colors.Black));
AddTexture(archive, "textures/blue_wave.btx", 64, 64, CreateGradient(64, 64, Colors.MidnightBlue, Colors.Crimson));
AddTexture(archive, "textures/ui/button_normal.btx", 256, 64, CreateGradient(256, 64, Colors.Gray, Colors.DarkRed));
AddTexture(archive, "textures/ui/button_hover.btx", 256, 64, CreateGradient(256, 64, Colors.Crimson, Colors.OrangeRed));
AddTexture(archive, "icons/logo.btx", 96, 96, CreateCheckerboard(96, 96));

// Обычные файлы
archive.Entries.Add(new BpcEntry
{
    Path = "config.xml",
    Data = System.Text.Encoding.UTF8.GetBytes("<config><version>1.0</version><name>TestPack</name></config>"),
    OriginalSize = 0
});
archive.Entries.Add(new BpcEntry
{
    Path = "data/settings.json",
    Data = System.Text.Encoding.UTF8.GetBytes("{\"quality\":\"high\",\"resolution\":[1920,1080]}"),
    OriginalSize = 0
});

// Обновляем OriginalSize
foreach (var e in archive.Entries)
    e.OriginalSize = (uint)e.Data.Length;

archive.Save(bpcPath);
Console.WriteLine($"Тестовый архив создан: {bpcPath}");
Console.WriteLine($"Записей: {archive.Entries.Count}");

// ─── Вспомогательные ──────────────────────────────────────────────
static void AddTexture(BpcArchive archive, string path, int w, int h, byte[] pixels)
{
    var tex = new BtxTexture
    {
        Width = w,
        Height = h,
        Format = BtxPixelFormat.Bgra32,
        PixelData = pixels
    };
    archive.Entries.Add(new BpcEntry
    {
        Path = path,
        Data = tex.ToBytes(),
        OriginalSize = (uint)tex.ToBytes().Length
    });
}

static byte[] CreateGradient(int w, int h, Color c1, Color c2)
{
    byte[] px = new byte[w * h * 4];
    for (int y = 0; y < h; y++)
    for (int x = 0; x < w; x++)
    {
        float t = (float)x / (w - 1);
        int i = (y * w + x) * 4;
        px[i + 0] = Lerp(c1.B, c2.B, t); // B
        px[i + 1] = Lerp(c1.G, c2.G, t); // G
        px[i + 2] = Lerp(c1.R, c2.R, t); // R
        px[i + 3] = 255;                  // A
    }
    return px;
}

static byte[] CreateCheckerboard(int w, int h)
{
    byte[] px = new byte[w * h * 4];
    for (int y = 0; y < h; y++)
    for (int x = 0; x < w; x++)
    {
        bool white = ((x / 8) + (y / 8)) % 2 == 0;
        int i = (y * w + x) * 4;
        byte v = white ? (byte)220 : (byte)30;
        px[i + 0] = v;   // B
        px[i + 1] = v;   // G
        px[i + 2] = white ? (byte)180 : (byte)200; // R = красный оттенок
        px[i + 3] = 255; // A
    }
    return px;
}

static byte Lerp(byte a, byte b, float t) => (byte)(a + (b - a) * t);
