// ═══════════════════════════════════════════════════════════════════════════
// AstcDecoder.cs — ASTC LDR texture decoder (no third-party dependencies)
// Decodes ASTC compressed blocks to BGRA32 pixel data.
// Supports block sizes used in BTX: 4x4, 5x4, 5x5, 6x5, 6x6, 8x5, 8x6,
// 8x8, 10x5, 10x6, 10x8, 10x10, 12x10, 12x12.
// Reference: Khronos ASTC specification / GL_KHR_texture_compression_astc_ldr
// ═══════════════════════════════════════════════════════════════════════════

using System;
using System.Runtime.CompilerServices;

namespace BpcEditor.Formats;

public static class AstcDecoder
{
    // GL internal format range for ASTC LDR
    private const int GL_COMPRESSED_RGBA_ASTC_4x4 = 0x93B0;
    private const int GL_COMPRESSED_RGBA_ASTC_12x12 = 0x93BD;

    // Block size table indexed by (internalFormat - 0x93B0)
    private static readonly (int w, int h)[] BlockSizes =
    {
        (4,4),(5,4),(5,5),(6,5),(6,6),(8,5),(8,6),(8,8),(10,5),(10,6),(10,8),(10,10),(12,10),(12,12)
    };

    public static bool IsAstcFormat(int internalFmt)
        => internalFmt >= GL_COMPRESSED_RGBA_ASTC_4x4 && internalFmt <= GL_COMPRESSED_RGBA_ASTC_12x12;

    public static void GetBlockSize(int internalFmt, out int bw, out int bh)
    {
        if (IsAstcFormat(internalFmt))
        {
            var s = BlockSizes[internalFmt - GL_COMPRESSED_RGBA_ASTC_4x4];
            bw = s.w; bh = s.h;
        }
        else { bw = 0; bh = 0; }
    }

    /// <summary>
    /// Decode ASTC compressed data to BGRA32 pixel array.
    /// </summary>
    public static byte[] Decode(byte[] data, int imgW, int imgH, int blockW, int blockH)
    {
        byte[] output = new byte[imgW * imgH * 4];
        int blocksX = (imgW + blockW - 1) / blockW;
        int blocksY = (imgH + blockH - 1) / blockH;

        Span<byte> blockBuf = stackalloc byte[16];

        for (int by = 0; by < blocksY; by++)
        {
            for (int bx = 0; bx < blocksX; bx++)
            {
                int blockIdx = by * blocksX + bx;
                int offset = blockIdx * 16;
                if (offset + 16 > data.Length) break;

                // Copy 16 bytes of block data
                data.AsSpan(offset, 16).CopyTo(blockBuf);

                DecodeBlock(blockBuf, blockW, blockH, bx * blockW, by * blockH, imgW, imgH, output);
            }
        }
        return output;
    }

    // ───────────────────────── Block decoding ─────────────────────────

    private static void DecodeBlock(ReadOnlySpan<byte> block, int blockW, int blockH,
        int baseX, int baseY, int imgW, int imgH, byte[] output)
    {
        ulong lo = BitConverter.ToUInt64(block);
        ulong hi = BitConverter.ToUInt64(block.Slice(8));

        if ((lo & 0x1FF) == 0x1FC)
        {
            DecodeVoidExtent(lo, hi, blockW, blockH, baseX, baseY, imgW, imgH, output);
            return;
        }

        int modeWord = (int)(lo & 0x7FF);
        if (!ParseBlockMode(modeWord, out int weightW, out int weightH,
                out bool dualPlane, out int weightRange))
        {
            FillError(blockW, blockH, baseX, baseY, imgW, imgH, output);
            return;
        }

        int realWeightCount = weightW * weightH * (dualPlane ? 2 : 1);
        int weightBits = ComputeIseBits(realWeightCount, weightRange);

        int partitionCount = GetBits(lo, hi, 11, 2) + 1;
        if (partitionCount > 4 || (dualPlane && partitionCount == 4))
        {
            FillError(blockW, blockH, baseX, baseY, imgW, imgH, output);
            return;
        }

        int belowWeightsPos = 128 - weightBits;

        // Parse partition index and CEM
        int partSeed = 0;
        int[] cem = new int[partitionCount];
        int encodedTypeHighpartSize = 0;
        int endpointDataStart;

        if (partitionCount == 1)
        {
            cem[0] = GetBits(lo, hi, 13, 4);
            endpointDataStart = 17;
        }
        else
        {
            partSeed = GetBits(lo, hi, 13, 10);
            encodedTypeHighpartSize = 3 * partitionCount - 4;
            belowWeightsPos -= encodedTypeHighpartSize;

            int encodedTypeLow = GetBits(lo, hi, 23, 6);
            int encodedTypeHigh = GetBits(lo, hi, belowWeightsPos, encodedTypeHighpartSize);
            int encodedType = encodedTypeLow | (encodedTypeHigh << 6);

            int baseclass = encodedType & 3;
            if (baseclass == 0)
            {
                // All partitions share the same CEM
                int c = (encodedType >> 2) & 0xF;
                for (int i = 0; i < partitionCount; i++) cem[i] = c;
                // Reclaim the high part bits since they aren't used
                belowWeightsPos += encodedTypeHighpartSize;
                encodedTypeHighpartSize = 0;
            }
            else
            {
                baseclass--;
                int bitpos = 2;
                for (int i = 0; i < partitionCount; i++)
                {
                    cem[i] = (((encodedType >> bitpos) & 1) + baseclass) << 2;
                    bitpos++;
                }
                for (int i = 0; i < partitionCount; i++)
                {
                    cem[i] |= (encodedType >> bitpos) & 3;
                    bitpos += 2;
                }
            }

            endpointDataStart = 29; // 13 + 10 (partition index) + 6 (CEM low)
        }

        // Dual plane component
        int dpChannel = 0;
        if (dualPlane)
        {
            dpChannel = GetBits(lo, hi, belowWeightsPos - 2, 2);
        }

        // Count total endpoint integers
        int totalEndpointValues = 0;
        for (int i = 0; i < partitionCount; i++)
            totalEndpointValues += (cem[i] >> 2) * 2 + 2;

        if (totalEndpointValues > 18 || totalEndpointValues < 2)
        {
            FillError(blockW, blockH, baseX, baseY, imgW, imgH, output);
            return;
        }

        // Calculate available color bits using the same formula as ARM reference
        int colorBits;
        if (partitionCount == 1)
            colorBits = 115 - 4 - weightBits - (dualPlane ? 2 : 0);
        else
            colorBits = 113 - 4 - 10 - weightBits - encodedTypeHighpartSize - (dualPlane ? 2 : 0);

        if (colorBits < 0) colorBits = 0;

        int endpointRange = FindEndpointRange(totalEndpointValues, colorBits);
        if (endpointRange < 0)
        {
            FillError(blockW, blockH, baseX, baseY, imgW, imgH, output);
            return;
        }

        // Decode endpoint ISE values
        int[] endpointVals = new int[totalEndpointValues];
        DecodeIse(lo, hi, endpointDataStart, totalEndpointValues, endpointRange, endpointVals);

        // Unquantize endpoints to 0-255
        UnquantizeEndpoints(endpointVals, endpointRange);

        // Decode weight ISE values (bit-reversed from bit 127)
        int[] weightVals = new int[realWeightCount];
        DecodeWeightsReverse(lo, hi, realWeightCount, weightRange, weightVals);

        // Unquantize weights to 0-64
        UnquantizeWeights(weightVals, weightRange);

        // Interpolate and write pixels
        int epOffset = 0;
        for (int i = 0; i < partitionCount; i++)
        {
            int epCount = (cem[i] >> 2) * 2 + 2;
            int[] ep = new int[epCount];
            Array.Copy(endpointVals, epOffset, ep, 0, epCount);
            epOffset += epCount;

            DecodeEndpoints(cem[i], ep, out int eR0, out int eG0, out int eB0, out int eA0,
                                        out int eR1, out int eG1, out int eB1, out int eA1);

            for (int py = 0; py < blockH; py++)
            {
                for (int px = 0; px < blockW; px++)
                {
                    int fx = baseX + px;
                    int fy = baseY + py;
                    if (fx >= imgW || fy >= imgH) continue;

                    int part = (partitionCount > 1) ? GetPartition(partitionCount, partSeed, blockW, blockH, px, py) : 0;
                    if (part != i) continue;

                    int w0 = InfillWeight(weightVals, weightW, weightH, blockW, blockH, px, py, dualPlane, 0);

                    int R, G, B, A;
                    if (dualPlane)
                    {
                        int w1 = InfillWeight(weightVals, weightW, weightH, blockW, blockH, px, py, true, 1);
                        R = InterpolateChannel(eR0, eR1, dpChannel == 0 ? w1 : w0);
                        G = InterpolateChannel(eG0, eG1, dpChannel == 1 ? w1 : w0);
                        B = InterpolateChannel(eB0, eB1, dpChannel == 2 ? w1 : w0);
                        A = InterpolateChannel(eA0, eA1, dpChannel == 3 ? w1 : w0);
                    }
                    else
                    {
                        R = InterpolateChannel(eR0, eR1, w0);
                        G = InterpolateChannel(eG0, eG1, w0);
                        B = InterpolateChannel(eB0, eB1, w0);
                        A = InterpolateChannel(eA0, eA1, w0);
                    }

                    int idx = (fy * imgW + fx) * 4;
                    output[idx + 0] = (byte)B;
                    output[idx + 1] = (byte)G;
                    output[idx + 2] = (byte)R;
                    output[idx + 3] = (byte)A;
                }
            }
        }
    }

    // ───────────────────── Void-Extent Block ─────────────────────

    private static void DecodeVoidExtent(ulong lo, ulong hi, int blockW, int blockH,
        int baseX, int baseY, int imgW, int imgH, byte[] output)
    {
        // Constant-color block: RGBA16 at bits 64-127
        int R = (int)((hi >> 0) & 0xFFFF);
        int G = (int)((hi >> 16) & 0xFFFF);
        int B = (int)((hi >> 32) & 0xFFFF);
        int A = (int)((hi >> 48) & 0xFFFF);

        // Convert UNORM16 to 8-bit
        byte r8 = (byte)(R >> 8);
        byte g8 = (byte)(G >> 8);
        byte b8 = (byte)(B >> 8);
        byte a8 = (byte)(A >> 8);

        for (int py = 0; py < blockH; py++)
        {
            for (int px = 0; px < blockW; px++)
            {
                int fx = baseX + px;
                int fy = baseY + py;
                if (fx >= imgW || fy >= imgH) continue;
                int idx = (fy * imgW + fx) * 4;
                output[idx + 0] = b8;
                output[idx + 1] = g8;
                output[idx + 2] = r8;
                output[idx + 3] = a8;
            }
        }
    }

    // ───────────────────── Block Mode Parsing ─────────────────────
    // The 11-bit block mode encodes weight grid dimensions, range, and dual-plane flag.

    private static bool ParseBlockMode(int mode, out int wW, out int wH,
        out bool dualPlane, out int weightRange)
    {
        wW = wH = 0;
        dualPlane = false;
        weightRange = 0;

        // Reference: ARM astc-encoder decode_block_mode_2d
        int baseQuantMode = (mode >> 4) & 1;
        int H = (mode >> 9) & 1;
        int D = (mode >> 10) & 1;
        int A = (mode >> 5) & 0x3;

        if ((mode & 3) != 0)
        {
            // bits[1:0] != 00
            baseQuantMode |= (mode & 3) << 1;
            int B = (mode >> 7) & 3;
            switch ((mode >> 2) & 3)
            {
                case 0:
                    wW = B + 4;
                    wH = A + 2;
                    break;
                case 1:
                    wW = B + 8;
                    wH = A + 2;
                    break;
                case 2:
                    wW = A + 2;
                    wH = B + 8;
                    break;
                case 3:
                    B &= 1;
                    if ((mode & 0x100) != 0)
                    {
                        wW = B + 2;
                        wH = A + 2;
                    }
                    else
                    {
                        wW = A + 2;
                        wH = B + 6;
                    }
                    break;
            }
        }
        else
        {
            // bits[1:0] == 00
            baseQuantMode |= ((mode >> 2) & 3) << 1;
            if (((mode >> 2) & 3) == 0)
                return false; // reserved

            int B = (mode >> 9) & 3;
            switch ((mode >> 7) & 3)
            {
                case 0:
                    wW = 12;
                    wH = A + 2;
                    break;
                case 1:
                    wW = A + 2;
                    wH = 12;
                    break;
                case 2:
                    wW = A + 6;
                    wH = B + 6;
                    D = 0;
                    H = 0;
                    break;
                case 3:
                    switch ((mode >> 5) & 3)
                    {
                        case 0:
                            wW = 6;
                            wH = 10;
                            break;
                        case 1:
                            wW = 10;
                            wH = 6;
                            break;
                        default:
                            return false;
                    }
                    break;
            }
        }

        dualPlane = D != 0;
        weightRange = (baseQuantMode - 2) + 6 * H;

        // Validate weight count and ISE bit budget
        int numWeights = wW * wH * (D + 1);
        if (numWeights > 64) return false;

        int weightBits = ComputeIseBits(numWeights, weightRange);
        if (weightBits < 24 || weightBits > 96) return false;

        if (wW < 2 || wH < 2 || wW > 12 || wH > 12) return false;
        if (weightRange < 0 || weightRange > 11) return false;
        return true;
    }

    // ───────────────────── Bit Extraction ─────────────────────

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    private static int GetBits(ulong lo, ulong hi, int start, int count)
    {
        if (count == 0) return 0;
        if (start >= 64)
            return (int)((hi >> (start - 64)) & ((1UL << count) - 1));
        if (start + count <= 64)
            return (int)((lo >> start) & ((1UL << count) - 1));
        // Straddles the boundary
        int loCount = 64 - start;
        int hiCount = count - loCount;
        ulong loVal = (lo >> start) & ((1UL << loCount) - 1);
        ulong hiVal = hi & ((1UL << hiCount) - 1);
        return (int)(loVal | (hiVal << loCount));
    }

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    private static int GetBitReverse(ulong lo, ulong hi, int revPos)
    {
        // revPos 0 = bit 127, revPos 1 = bit 126, etc.
        int bitPos = 127 - revPos;
        if (bitPos >= 64)
            return (int)((hi >> (bitPos - 64)) & 1);
        return (int)((lo >> bitPos) & 1);
    }

    // ───────────────────── ISE Encoding Parameters ─────────────────────

    // Weight range → (trits, quints, bits) for ISE
    // Range index 0..11 corresponds to quantization levels
    private static readonly (int trits, int quints, int bits)[] RangeTable =
    {
        (0, 0, 1), // 0: 2 levels
        (1, 0, 0), // 1: 3 levels (trit)
        (0, 1, 0), // 2: 5 levels (quint)
        (0, 0, 2), // 3: 4 levels
        (1, 0, 1), // 4: 6 levels (trit+1bit)
        (0, 1, 1), // 5: 10 levels (quint+1bit)
        (0, 0, 3), // 6: 8 levels
        (1, 0, 2), // 7: 12 levels (trit+2bits)
        (0, 1, 2), // 8: 20 levels (quint+2bits)
        (0, 0, 4), // 9: 16 levels
        (1, 0, 3), // 10: 24 levels (trit+3bits)
        (0, 1, 3), // 11: 40 levels (quint+3bits)
    };

    // Extended range table supporting up to range index 20 (endpoint quantization)
    private static readonly (int trits, int quints, int bits)[] ExtRangeTable =
    {
        (0, 0, 1), //  0: 2
        (1, 0, 0), //  1: 3
        (0, 1, 0), //  2: 5
        (0, 0, 2), //  3: 4
        (1, 0, 1), //  4: 6
        (0, 1, 1), //  5: 10
        (0, 0, 3), //  6: 8
        (1, 0, 2), //  7: 12
        (0, 1, 2), //  8: 20
        (0, 0, 4), //  9: 16
        (1, 0, 3), // 10: 24
        (0, 1, 3), // 11: 40
        (0, 0, 5), // 12: 32
        (1, 0, 4), // 13: 48
        (0, 1, 4), // 14: 80
        (0, 0, 6), // 15: 64
        (1, 0, 5), // 16: 96
        (0, 1, 5), // 17: 160
        (0, 0, 7), // 18: 128
        (1, 0, 6), // 19: 192
        (0, 1, 6), // 20: 320
    };

    private static int LevelsForRange(int range)
    {
        if (range < 0 || range >= ExtRangeTable.Length) return 0;
        var (t, q, b) = ExtRangeTable[range];
        int base_ = 1 << b;
        if (t != 0) return base_ * 3;
        if (q != 0) return base_ * 5;
        return base_;
    }

    private static int ComputeIseBits(int count, int range)
    {
        if (range < 0 || range >= ExtRangeTable.Length) return 0;
        var (t, q, b) = ExtRangeTable[range];
        if (t != 0)
        {
            // Trit encoding: ceil(8*n/5) + n*b
            return (8 * count + 4) / 5 + count * b;
        }
        if (q != 0)
        {
            // Quint encoding: ceil(7*n/3) + n*b
            return (7 * count + 2) / 3 + count * b;
        }
        return count * b;
    }

    // ───────────────────── ISE Decoding ─────────────────────

    private static void DecodeIse(ulong lo, ulong hi, int bitOffset,
        int count, int range, int[] result)
    {
        if (range >= ExtRangeTable.Length) return;
        var (trits, quints, bits) = ExtRangeTable[range];

        if (trits != 0)
            DecodeIseTrit(lo, hi, bitOffset, count, bits, result);
        else if (quints != 0)
            DecodeIseQuint(lo, hi, bitOffset, count, bits, result);
        else
            DecodeIseBits(lo, hi, bitOffset, count, bits, result);
    }

    private static void DecodeIseBits(ulong lo, ulong hi, int bitOffset,
        int count, int bits, int[] result)
    {
        int pos = bitOffset;
        for (int i = 0; i < count; i++)
        {
            result[i] = GetBits(lo, hi, pos, bits);
            pos += bits;
        }
    }

    private static void DecodeIseTrit(ulong lo, ulong hi, int bitOffset,
        int count, int valueBits, int[] result)
    {
        // Trits are encoded in groups of 5:
        // The trit bits and value bits are interleaved in the bitstream.
        // Layout per group of 5 values (v0..v4):
        //   m0[valueBits], T[1:0], m1[valueBits], T[3:2], m2[valueBits], T[4],
        //   m3[valueBits], T[6:5], m4[valueBits], T[7]
        // Total bits per group: 5*valueBits + 8

        int pos = bitOffset;
        int idx = 0;
        while (idx < count)
        {
            int groupSize = Math.Min(5, count - idx);

            // Read interleaved m and T bits
            int[] m = new int[5];
            int tBits = 0;

            // m0
            m[0] = (groupSize > 0) ? GetBits(lo, hi, pos, valueBits) : 0;
            pos += valueBits;
            // T[1:0]
            tBits |= GetBits(lo, hi, pos, 2);
            pos += 2;

            // m1
            m[1] = (groupSize > 1) ? GetBits(lo, hi, pos, valueBits) : 0;
            pos += valueBits;
            // T[3:2]
            tBits |= GetBits(lo, hi, pos, 2) << 2;
            pos += 2;

            // m2
            m[2] = (groupSize > 2) ? GetBits(lo, hi, pos, valueBits) : 0;
            pos += valueBits;
            // T[4]
            tBits |= GetBits(lo, hi, pos, 1) << 4;
            pos += 1;

            // m3
            m[3] = (groupSize > 3) ? GetBits(lo, hi, pos, valueBits) : 0;
            pos += valueBits;
            // T[6:5]
            tBits |= GetBits(lo, hi, pos, 2) << 5;
            pos += 2;

            // m4
            m[4] = (groupSize > 4) ? GetBits(lo, hi, pos, valueBits) : 0;
            pos += valueBits;
            // T[7]
            tBits |= GetBits(lo, hi, pos, 1) << 7;
            pos += 1;

            // Decode trits from packed trit block (base-243)
            int T = tBits;
            if (T >= 243) T = 0;

            int t0 = T % 3; T /= 3;
            int t1 = T % 3; T /= 3;
            int t2 = T % 3; T /= 3;
            int t3 = T % 3; T /= 3;
            int t4 = T;

            // Combine: value = m + trit * (1 << valueBits)
            int[] tritsArr = { t0, t1, t2, t3, t4 };
            for (int i = 0; i < groupSize; i++)
            {
                result[idx + i] = m[i] | (tritsArr[i] << valueBits);
            }
            idx += 5;
        }
    }

    private static void DecodeIseQuint(ulong lo, ulong hi, int bitOffset,
        int count, int valueBits, int[] result)
    {
        // Quints are encoded in groups of 3:
        // Layout per group of 3 values:
        //   m0[valueBits], Q[2:0], m1[valueBits], Q[4:3], m2[valueBits], Q[6:5]
        // Total bits per group: 3*valueBits + 7

        int pos = bitOffset;
        int idx = 0;
        while (idx < count)
        {
            int groupSize = Math.Min(3, count - idx);

            int[] m = new int[3];
            int qBits = 0;

            // m0
            m[0] = (groupSize > 0) ? GetBits(lo, hi, pos, valueBits) : 0;
            pos += valueBits;
            // Q[2:0]
            qBits |= GetBits(lo, hi, pos, 3);
            pos += 3;

            // m1
            m[1] = (groupSize > 1) ? GetBits(lo, hi, pos, valueBits) : 0;
            pos += valueBits;
            // Q[4:3]
            qBits |= GetBits(lo, hi, pos, 2) << 3;
            pos += 2;

            // m2
            m[2] = (groupSize > 2) ? GetBits(lo, hi, pos, valueBits) : 0;
            pos += valueBits;
            // Q[6:5]
            qBits |= GetBits(lo, hi, pos, 2) << 5;
            pos += 2;

            // Decode quints from packed quint block (base-125)
            int Q = qBits;
            if (Q >= 125) Q = 0;

            int q0 = Q % 5; Q /= 5;
            int q1 = Q % 5; Q /= 5;
            int q2 = Q;

            int[] quintsArr = { q0, q1, q2 };
            for (int i = 0; i < groupSize; i++)
            {
                result[idx + i] = m[i] | (quintsArr[i] << valueBits);
            }
            idx += 3;
        }
    }

    // ───────────────────── Weight ISE Decoding (Reverse) ─────────────────────
    // Weights are stored from bit 127 downward (reverse bit order).

    private static void DecodeWeightsReverse(ulong lo, ulong hi,
        int count, int range, int[] result)
    {
        // Reverse the bit data for weight decoding
        ulong rLo, rHi;
        ReverseBits128(lo, hi, out rLo, out rHi);

        if (range >= RangeTable.Length) return;
        DecodeIse(rLo, rHi, 0, count, range, result);
    }

    private static void ReverseBits128(ulong lo, ulong hi, out ulong rLo, out ulong rHi)
    {
        rLo = ReverseBits64(hi);
        rHi = ReverseBits64(lo);
    }

    private static ulong ReverseBits64(ulong v)
    {
        v = ((v >> 1) & 0x5555555555555555UL) | ((v & 0x5555555555555555UL) << 1);
        v = ((v >> 2) & 0x3333333333333333UL) | ((v & 0x3333333333333333UL) << 2);
        v = ((v >> 4) & 0x0F0F0F0F0F0F0F0FUL) | ((v & 0x0F0F0F0F0F0F0F0FUL) << 4);
        v = ((v >> 8) & 0x00FF00FF00FF00FFUL) | ((v & 0x00FF00FF00FF00FFUL) << 8);
        v = ((v >> 16) & 0x0000FFFF0000FFFFUL) | ((v & 0x0000FFFF0000FFFFUL) << 16);
        v = (v >> 32) | (v << 32);
        return v;
    }

    // ───────────────────── Endpoint Range Finding ─────────────────────

    private static int FindEndpointRange(int count, int availBits)
    {
        // Find the largest range index such that the ISE for count values
        // fits within availBits bits. Minimum valid endpoint range is 4 (QUANT_6 = 6 levels).
        for (int r = ExtRangeTable.Length - 1; r >= 0; r--)
        {
            if (ComputeIseBits(count, r) <= availBits)
                return r >= 4 ? r : -1;
        }
        return -1;
    }

    // ───────────────────── Endpoint Unquantization ─────────────────────

    private static void UnquantizeEndpoints(int[] vals, int range)
    {
        int levels = LevelsForRange(range);
        for (int i = 0; i < vals.Length; i++)
        {
            vals[i] = UnquantizeValue(vals[i], range, levels);
        }
    }

    private static int UnquantizeValue(int v, int range, int levels)
    {
        // Unquantize ISE value to 0-255 for endpoints
        if (range >= ExtRangeTable.Length) return 0;
        var (t, q, b) = ExtRangeTable[range];

        if (t != 0)
        {
            int trit = v >> b;
            int m = v & ((1 << b) - 1);
            return UnquantizeTrit(trit, m, b);
        }
        if (q != 0)
        {
            int quint = v >> b;
            int m = v & ((1 << b) - 1);
            return UnquantizeQuint(quint, m, b);
        }
        // Pure bits
        return UnquantizeBits(v, b);
    }

    private static int UnquantizeTrit(int trit, int m, int bits)
    {
        // Table C.2.15 from ASTC spec: unquantize a trit-based value
        if (bits == 0)
        {
            // 3 levels: 0,1,2 → 0,128,255
            return trit == 0 ? 0 : (trit == 1 ? 128 : 255);
        }

        int A, B, C, D;
        m = BitReverse(m, bits);

        switch (bits)
        {
            case 1:
                A = m == 0 ? 0 : 255;
                return trit switch { 0 => A, 1 => (A >> 1) + 128, _ => 255 - A };
            case 2:
                // bits = 2, m has been reversed to 2 bits
                A = (m << 6) | (m << 4) | (m << 2) | m; // replicate 2 bits to 8 bits
                B = trit switch { 0 => 0, 1 => 204, _ => 255 };
                C = trit switch { 0 => 0, 1 => 93, _ => 255 };
                return (A * (255 - C) + B * C + 128) / 255;
            default:
                // General formula for bits >= 3
                // Use the standard ASTC unquantization
                return UnquantizeTritGeneral(trit, m, bits);
        }
    }

    private static int UnquantizeTritGeneral(int trit, int m, int bits)
    {
        // From ASTC spec: unquantize(trit, m, bits)
        // A = {m, 0} replicated, D from trit
        int A;
        if (m == 0)
            A = 0;
        else
        {
            A = (1 << (bits + 1)) - 1; // all 1s in (bits+1) positions
            // Actually we need m bit-reversed and replicated
            // Let me use a simpler approach:
            A = m; // m is already bit-reversed
            // Replicate to 9 bits
            int rep = 0;
            int shift = 0;
            while (shift < 9)
            {
                rep |= (A << shift);
                shift += bits;
            }
            A = rep & 0x1FF; // 9 bits
        }

        int D = trit switch
        {
            0 => 0,
            1 => 204,
            _ => 511
        };

        int T = D * 128 + A * 128 - D * A;
        T = (T + 256) >> 9;
        return Math.Clamp(T, 0, 255);
    }

    private static int UnquantizeQuint(int quint, int m, int bits)
    {
        if (bits == 0)
        {
            // 5 levels: 0,1,2,3,4 → 0,64,128,191,255
            return quint * 255 / 4;
        }

        // For quint-based: similar to trit but with 5 levels
        m = BitReverse(m, bits);

        int A;
        if (m == 0)
            A = 0;
        else
        {
            int rep = 0;
            int shift = 0;
            while (shift < 9)
            {
                rep |= (m << shift);
                shift += bits;
            }
            A = rep & 0x1FF;
        }

        int D = quint switch
        {
            0 => 0,
            1 => 113,
            2 => 204,
            3 => 340,
            _ => 511
        };

        int T = D * 128 + A * 128 - D * A;
        T = (T + 256) >> 9;
        return Math.Clamp(T, 0, 255);
    }

    private static int UnquantizeBits(int v, int bits)
    {
        if (bits == 1) return v * 255;
        if (bits == 8) return v;
        // Bit replication to 8 bits
        int result = 0;
        int shift = 0;
        int rv = BitReverse(v, bits);
        while (shift < 8)
        {
            result |= (rv << shift);
            shift += bits;
        }
        return (result >> (shift - 8)) & 0xFF;
    }

    private static int BitReverse(int val, int bits)
    {
        int result = 0;
        for (int i = 0; i < bits; i++)
        {
            result = (result << 1) | (val & 1);
            val >>= 1;
        }
        return result;
    }

    // ───────────────────── Weight Unquantization ─────────────────────

    private static void UnquantizeWeights(int[] vals, int range)
    {
        for (int i = 0; i < vals.Length; i++)
        {
            vals[i] = UnquantizeWeight(vals[i], range);
        }
    }

    // Unquantize weight to 0-64 range
    private static int UnquantizeWeight(int v, int range)
    {
        // From ASTC spec Section C.2.18: Weight unquantization
        // First, unquantize ISE value to intermediate 0-63, then scale

        var (t, q, bits) = RangeTable[range];
        int unq;

        if (t != 0)
        {
            int trit = v >> bits;
            int m = v & ((1 << bits) - 1);
            unq = UnquantizeWeightTrit(trit, m, bits);
        }
        else if (q != 0)
        {
            int quint = v >> bits;
            int m = v & ((1 << bits) - 1);
            unq = UnquantizeWeightQuint(quint, m, bits);
        }
        else
        {
            unq = UnquantizeWeightBits(v, bits);
        }

        // Final: turn 0-63 into 0-64
        if (unq > 32)
            unq++;
        return Math.Clamp(unq, 0, 64);
    }

    private static int UnquantizeWeightTrit(int trit, int m, int bits)
    {
        // Table C.2.24 — weight unquantization for trit modes
        if (bits == 0) return trit * 32; // 0, 32, 63
        
        int A, B, C;
        switch (bits)
        {
            case 1:
                C = 50;
                A = m != 0 ? 0x7F : 0;
                break;
            case 2:
                C = 23;
                A = (m & 2) != 0 ? 0x7F : 0;
                A |= (m & 1) != 0 ? 0x3F : 0;
                A &= 0x7F;
                break;
            default: // 3
                C = 11;
                m = BitReverse(m, bits);
                A = 0;
                int shift = 0;
                while (shift < 7) { A |= m << shift; shift += bits; }
                A &= 0x7F;
                break;
        }
        B = trit switch { 0 => 0, 1 => C, _ => 2 * C };
        int result = (A * (64 - 2 * C) + B * 128 + 32) >> 6;
        return Math.Clamp(result >> 1, 0, 63);
    }

    private static int UnquantizeWeightQuint(int quint, int m, int bits)
    {
        if (bits == 0) return quint * 16; // 0, 16, 32, 48, 63
        
        int A, B, C;
        switch (bits)
        {
            case 1:
                C = 28;
                A = m != 0 ? 0x7F : 0;
                break;
            default: // 2
                C = 13;
                m = BitReverse(m, bits);
                A = 0;
                int shift = 0;
                while (shift < 7) { A |= m << shift; shift += bits; }
                A &= 0x7F;
                break;
        }
        B = quint * C;
        int result = (A * (64 - 4 * C) + B * 128 + 32) >> 6;
        return Math.Clamp(result >> 1, 0, 63);
    }

    private static int UnquantizeWeightBits(int v, int bits)
    {
        // Direct bit weight
        switch (bits)
        {
            case 1: return v * 63;
            case 2: return v * 21; // 0,21,42,63
            case 3: return v * 9;  // 0,9,18,...,63
            case 4: return v * 4 + (v >> 2); // approximate
            default: return v;
        }
    }

    // ───────────────────── Bilinear Weight Infill ─────────────────────

    private static int InfillWeight(int[] weights, int wW, int wH,
        int blockW, int blockH, int px, int py, bool dualPlane, int plane)
    {
        // ASTC spec C.2.19: weight infill
        // Ds = floor((1024 + floor(N/2)) / (N - 1))
        // cs = Ds * texelPos
        // gs = (cs * (gridDim - 1) + 32) >> 6
        int DsX = (1024 + blockW / 2) / (blockW - 1);
        int DsY = (1024 + blockH / 2) / (blockH - 1);

        int gX = (DsX * px * (wW - 1) + 32) >> 6;
        int gY = (DsY * py * (wH - 1) + 32) >> 6;

        int jX = gX >> 4;
        int jY = gY >> 4;

        int fX2 = gX & 0xF;
        int fY2 = gY & 0xF;

        // Clamp grid coordinates
        int x0 = Math.Clamp(jX, 0, wW - 1);
        int y0 = Math.Clamp(jY, 0, wH - 1);
        int x1 = Math.Min(x0 + 1, wW - 1);
        int y1 = Math.Min(y0 + 1, wH - 1);

        int stride = dualPlane ? 2 : 1;
        int off = plane;

        int w00 = weights[y0 * wW * stride + x0 * stride + off];
        int w10 = weights[y0 * wW * stride + x1 * stride + off];
        int w01 = weights[y1 * wW * stride + x0 * stride + off];
        int w11 = weights[y1 * wW * stride + x1 * stride + off];

        // Bilinear interpolation (16 steps)
        int w = (w00 * (16 - fX2) * (16 - fY2) +
                 w10 * fX2 * (16 - fY2) +
                 w01 * (16 - fX2) * fY2 +
                 w11 * fX2 * fY2 + 128) >> 8;

        return Math.Clamp(w, 0, 64);
    }

    // ───────────────────── Channel Interpolation ─────────────────────

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    private static int InterpolateChannel(int e0, int e1, int weight)
    {
        // weight is 0-64; output is byte (0-255)
        return Math.Clamp((e0 * (64 - weight) + e1 * weight + 32) >> 6, 0, 255);
    }

    // ───────────────────── Endpoint Mode Count ─────────────────────

    private static int EndpointPairCount(int cem)
    {
        // Number of endpoint values for a given CEM
        return cem switch
        {
            0 => 2,   // LDR Luminance, direct
            1 => 2,   // LDR Luminance, base+offset
            2 => 4,   // HDR Luminance, large range
            3 => 4,   // HDR Luminance, small range  
            4 => 4,   // LDR Luminance+Alpha, direct
            5 => 4,   // LDR Luminance+Alpha, base+offset
            6 => 4,   // LDR RGB, base+scale
            7 => 4,   // HDR RGB, base+scale
            8 => 6,   // LDR RGB, direct
            9 => 6,   // LDR RGB, base+offset
            10 => 6,  // LDR RGB, base+scale+2 offset
            11 => 6,  // HDR RGB
            12 => 8,  // LDR RGBA, direct
            13 => 8,  // LDR RGBA, base+offset
            14 => 8,  // HDR RGB + LDR Alpha
            15 => 8,  // HDR RGBA
            _ => 2,
        };
    }

    // ───────────────────── Endpoint Decoding ─────────────────────

    private static void DecodeEndpoints(int cem, int[] ep,
        out int R0, out int G0, out int B0, out int A0,
        out int R1, out int G1, out int B1, out int A1)
    {
        R0 = G0 = B0 = 0; A0 = 255;
        R1 = G1 = B1 = 0; A1 = 255;

        switch (cem)
        {
            case 0: // LDR Luminance, direct
                R0 = G0 = B0 = ep[0];
                R1 = G1 = B1 = ep[1];
                break;

            case 1: // LDR Luminance, base+offset
            {
                int L0 = ep[0];
                int L1 = ep[1];
                BitTransferSigned(ref L1, ref L0);
                L1 = Math.Clamp(L0 + L1, 0, 255);
                L0 = Math.Clamp(L0, 0, 255);
                R0 = G0 = B0 = L0;
                R1 = G1 = B1 = L1;
                break;
            }

            case 4: // LDR Luminance+Alpha, direct
                R0 = G0 = B0 = ep[0]; A0 = ep[2];
                R1 = G1 = B1 = ep[1]; A1 = ep[3];
                break;

            case 5: // LDR Luminance+Alpha, base+offset
            {
                int L0 = ep[0], L1 = ep[1], A0v = ep[2], A1v = ep[3];
                BitTransferSigned(ref L1, ref L0);
                BitTransferSigned(ref A1v, ref A0v);
                R0 = G0 = B0 = Math.Clamp(L0, 0, 255);
                R1 = G1 = B1 = Math.Clamp(L0 + L1, 0, 255);
                A0 = Math.Clamp(A0v, 0, 255);
                A1 = Math.Clamp(A0v + A1v, 0, 255);
                break;
            }

            case 6: // LDR RGB, base+scale
            {
                R0 = (ep[0] * ep[3]) >> 8;
                G0 = (ep[1] * ep[3]) >> 8;
                B0 = (ep[2] * ep[3]) >> 8;
                R1 = ep[0]; G1 = ep[1]; B1 = ep[2];
                break;
            }

            case 8: // LDR RGB, direct
                R0 = ep[0]; R1 = ep[1];
                G0 = ep[2]; G1 = ep[3];
                B0 = ep[4]; B1 = ep[5];
                break;

            case 9: // LDR RGB, base+offset  
            {
                int r0 = ep[0], r1 = ep[1], g0 = ep[2], g1 = ep[3], b0 = ep[4], b1 = ep[5];
                BitTransferSigned(ref r1, ref r0);
                BitTransferSigned(ref g1, ref g0);
                BitTransferSigned(ref b1, ref b0);
                R0 = Math.Clamp(r0, 0, 255); R1 = Math.Clamp(r0 + r1, 0, 255);
                G0 = Math.Clamp(g0, 0, 255); G1 = Math.Clamp(g0 + g1, 0, 255);
                B0 = Math.Clamp(b0, 0, 255); B1 = Math.Clamp(b0 + b1, 0, 255);
                break;
            }

            case 10: // LDR RGB, base + scale + two offset
            {
                R0 = (ep[0] * ep[3]) >> 8;
                G0 = (ep[1] * ep[3]) >> 8;
                B0 = (ep[2] * ep[3]) >> 8;
                R1 = ep[0]; G1 = ep[1]; B1 = ep[2];
                // Offsets applied to endpoint 0
                int s0 = ep[4], s1 = ep[5];
                R0 = Math.Clamp(R0 - s0, 0, 255);
                G0 = Math.Clamp(G0 - s0, 0, 255);
                B0 = Math.Clamp(B0 - s1, 0, 255);
                break;
            }

            case 12: // LDR RGBA, direct
                R0 = ep[0]; R1 = ep[1];
                G0 = ep[2]; G1 = ep[3];
                B0 = ep[4]; B1 = ep[5];
                A0 = ep[6]; A1 = ep[7];
                break;

            case 13: // LDR RGBA, base+offset
            {
                int r0 = ep[0], r1 = ep[1], g0 = ep[2], g1 = ep[3];
                int b0 = ep[4], b1 = ep[5], a0 = ep[6], a1 = ep[7];
                BitTransferSigned(ref r1, ref r0);
                BitTransferSigned(ref g1, ref g0);
                BitTransferSigned(ref b1, ref b0);
                BitTransferSigned(ref a1, ref a0);
                R0 = Math.Clamp(r0, 0, 255); R1 = Math.Clamp(r0 + r1, 0, 255);
                G0 = Math.Clamp(g0, 0, 255); G1 = Math.Clamp(g0 + g1, 0, 255);
                B0 = Math.Clamp(b0, 0, 255); B1 = Math.Clamp(b0 + b1, 0, 255);
                A0 = Math.Clamp(a0, 0, 255); A1 = Math.Clamp(a0 + a1, 0, 255);
                break;
            }

            default:
                // HDR modes (2,3,7,11,14,15) — simplified: treat as LDR with available values
                if (ep.Length >= 8)
                {
                    R0 = ep[0]; R1 = ep[1]; G0 = ep[2]; G1 = ep[3];
                    B0 = ep[4]; B1 = ep[5]; A0 = ep[6]; A1 = ep[7];
                }
                else if (ep.Length >= 6)
                {
                    R0 = ep[0]; R1 = ep[1]; G0 = ep[2]; G1 = ep[3];
                    B0 = ep[4]; B1 = ep[5];
                }
                else if (ep.Length >= 4)
                {
                    R0 = G0 = B0 = ep[0]; A0 = ep[2];
                    R1 = G1 = B1 = ep[1]; A1 = ep[3];
                }
                else if (ep.Length >= 2)
                {
                    R0 = G0 = B0 = ep[0];
                    R1 = G1 = B1 = ep[1];
                }
                break;
        }
    }

    private static void BitTransferSigned(ref int a, ref int b)
    {
        // ASTC bit_transfer_signed operation
        b >>= 1;
        b |= a & 0x80;
        a >>= 1;
        a &= 0x3F;
        if ((a & 0x20) != 0) a -= 0x40;
    }

    // ───────────────────── Partition Selection ─────────────────────

    private static int GetPartition(int numParts, int seed, int blockW, int blockH, int x, int y)
    {
        if (numParts == 1) return 0;

        bool smallBlock = blockW * blockH < 32;
        int partIndex = SelectPartition(seed, x, y, 0, numParts, smallBlock);
        return Math.Clamp(partIndex, 0, numParts - 1);
    }

    private static int SelectPartition(int seed, int x, int y, int z, int partCount, bool small)
    {
        // From ASTC spec / ARM reference astcenc_partition_tables.cpp
        if (partCount == 1) return 0;

        if (small) { x <<= 1; y <<= 1; z <<= 1; }

        seed += (partCount - 1) * 1024;

        uint rnum = Hash52((uint)seed);
        int seed1  = (int)(rnum        & 0xF);
        int seed2  = (int)((rnum >> 4)  & 0xF);
        int seed3  = (int)((rnum >> 8)  & 0xF);
        int seed4  = (int)((rnum >> 12) & 0xF);
        int seed5  = (int)((rnum >> 16) & 0xF);
        int seed6  = (int)((rnum >> 20) & 0xF);
        int seed7  = (int)((rnum >> 24) & 0xF);
        int seed8  = (int)((rnum >> 28) & 0xF);
        int seed9  = (int)((rnum >> 18) & 0xF);
        int seed10 = (int)((rnum >> 22) & 0xF);
        int seed11 = (int)((rnum >> 26) & 0xF);
        int seed12 = (int)(((rnum >> 30) | (rnum << 2)) & 0xF);

        seed1  *= seed1;  seed2  *= seed2;
        seed3  *= seed3;  seed4  *= seed4;
        seed5  *= seed5;  seed6  *= seed6;
        seed7  *= seed7;  seed8  *= seed8;
        seed9  *= seed9;  seed10 *= seed10;
        seed11 *= seed11; seed12 *= seed12;

        int sh1, sh2;
        if ((seed & 1) != 0)
        {
            sh1 = (seed & 2) != 0 ? 4 : 5;
            sh2 = partCount == 3 ? 6 : 5;
        }
        else
        {
            sh1 = partCount == 3 ? 6 : 5;
            sh2 = (seed & 2) != 0 ? 4 : 5;
        }
        int sh3 = (seed & 0x10) != 0 ? sh1 : sh2;

        seed1  >>= sh1; seed2  >>= sh2;
        seed3  >>= sh1; seed4  >>= sh2;
        seed5  >>= sh1; seed6  >>= sh2;
        seed7  >>= sh1; seed8  >>= sh2;
        seed9  >>= sh3; seed10 >>= sh3;
        seed11 >>= sh3; seed12 >>= sh3;

        int a  = seed1  * x + seed2  * y + seed11 * z + (int)(rnum >> 14);
        int b_ = seed3  * x + seed4  * y + seed12 * z + (int)(rnum >> 10);
        int c  = seed5  * x + seed6  * y + seed9  * z + (int)(rnum >> 6);
        int d  = seed7  * x + seed8  * y + seed10 * z + (int)(rnum >> 2);

        a &= 0x3F; b_ &= 0x3F; c &= 0x3F; d &= 0x3F;

        if (partCount <= 3) d = 0;
        if (partCount <= 2) c = 0;

        if (a >= b_ && a >= c && a >= d) return 0;
        if (b_ >= c && b_ >= d) return 1;
        if (c >= d) return 2;
        return 3;
    }

    private static uint Hash52(uint inp)
    {
        inp ^= inp >> 15;
        inp = (uint)((ulong)inp * 0xEEDE0891UL);
        inp ^= inp >> 5;
        inp += inp << 16;
        inp ^= inp >> 7;
        inp ^= inp >> 3;
        inp ^= inp << 6;
        inp ^= inp >> 17;
        return inp;
    }

    // ───────────────────── Multi-partition CEM parsing ─────────────────────

    private static void ParseMultiPartCem(ulong lo, ulong hi, int cemBase,
        int numParts, int[] cem, out int cemEnd)
    {
        // From ASTC spec C.2.10: multi-partition CEM
        // Bits [cemBase+1 : cemBase] = CEM class (1-3)
        // Then variable number of extra bits

        int cemClass = GetBits(lo, hi, cemBase, 2); // 2 bits for base class
        int bitPos = cemBase + 2;

        if (cemClass == 0)
        {
            // Single CEM for all partitions
            int c = GetBits(lo, hi, bitPos, 4);
            for (int i = 0; i < numParts; i++) cem[i] = c;
            cemEnd = bitPos + 4;
        }
        else
        {
            // Per-partition CEM
            int baseC = ((cemClass - 1) << 2);

            for (int i = 0; i < numParts; i++)
            {
                int bit = GetBits(lo, hi, bitPos, 1);
                int m = GetBits(lo, hi, bitPos + 1, 2);
                cem[i] = baseC + bit * 4 + m;
                bitPos += 3;
            }
            cemEnd = bitPos;
        }
    }

    // ───────────────────── Fill error block ─────────────────────

    private static void FillError(int blockW, int blockH, int baseX, int baseY,
        int imgW, int imgH, byte[] output)
    {
        for (int py = 0; py < blockH; py++)
        {
            for (int px = 0; px < blockW; px++)
            {
                int fx = baseX + px;
                int fy = baseY + py;
                if (fx >= imgW || fy >= imgH) continue;
                int idx = (fy * imgW + fx) * 4;
                output[idx + 0] = 255; // B
                output[idx + 1] = 0;   // G
                output[idx + 2] = 255; // R
                output[idx + 3] = 255; // A (magenta)
            }
        }
    }
}
