using System.IO.Compression;

string bpcPath = @"C:\Users\babin\Downloads\jj\BpcEditor\TestData\test_archive.bpc";
// Ищем реальные bpc файлы
var bpcFiles = Directory.GetFiles(@"C:\Users\babin\Downloads", "*.bpc", SearchOption.AllDirectories)
    .Where(f => !f.Contains("TestData"))
    .Take(5)
    .ToArray();

Console.WriteLine("=== Найденные BPC файлы: ===");
foreach (var f in bpcFiles)
    Console.WriteLine($"  {f} ({new FileInfo(f).Length} bytes)");

if (bpcFiles.Length > 0)
{
    string file = bpcFiles[0];
    Console.WriteLine($"\n=== Анализ: {file} ===");
    
    // Открываем как ZIP
    using var fs = File.OpenRead(file);
    using var zip = new ZipArchive(fs, ZipArchiveMode.Read);
    
    // Берём первый .btx файл
    var btxEntry = zip.Entries.FirstOrDefault(e => e.Name.EndsWith(".btx", StringComparison.OrdinalIgnoreCase));
    if (btxEntry != null)
    {
        Console.WriteLine($"\nBTX файл: {btxEntry.FullName} ({btxEntry.Length} bytes)");
        using var es = btxEntry.Open();
        using var ms = new MemoryStream();
        es.CopyTo(ms);
        byte[] data = ms.ToArray();
        
        Console.WriteLine($"Размер: {data.Length} bytes");
        Console.WriteLine($"\nПервые 128 байт (hex):");
        for (int i = 0; i < Math.Min(128, data.Length); i++)
        {
            Console.Write($"{data[i]:X2} ");
            if ((i + 1) % 16 == 0) Console.WriteLine();
        }
        Console.WriteLine();
        
        Console.WriteLine($"\nПервые 64 байт (ASCII):");
        for (int i = 0; i < Math.Min(64, data.Length); i++)
        {
            char c = (char)data[i];
            Console.Write(c >= 32 && c < 127 ? c : '.');
        }
        Console.WriteLine();
        
        // Попробуем разные интерпретации
        Console.WriteLine($"\nИнтерпретация заголовка:");
        if (data.Length >= 32)
        {
            Console.WriteLine($"  Bytes 0-3: {data[0]:X2} {data[1]:X2} {data[2]:X2} {data[3]:X2}");
            Console.WriteLine($"  Int32 @ 0: {BitConverter.ToInt32(data, 0)}");
            Console.WriteLine($"  Int32 @ 4: {BitConverter.ToInt32(data, 4)}");
            Console.WriteLine($"  Int32 @ 8: {BitConverter.ToInt32(data, 8)}");
            Console.WriteLine($"  Int32 @ 12: {BitConverter.ToInt32(data, 12)}");
            Console.WriteLine($"  Int32 @ 16: {BitConverter.ToInt32(data, 16)}");
            Console.WriteLine($"  Int32 @ 20: {BitConverter.ToInt32(data, 20)}");
            Console.WriteLine($"  Int32 @ 24: {BitConverter.ToInt32(data, 24)}");
            Console.WriteLine($"  Int32 @ 28: {BitConverter.ToInt32(data, 28)}");
            
            Console.WriteLine($"\n  UInt16 @ 0: {BitConverter.ToUInt16(data, 0)}");
            Console.WriteLine($"  UInt16 @ 2: {BitConverter.ToUInt16(data, 2)}");
            Console.WriteLine($"  UInt16 @ 4: {BitConverter.ToUInt16(data, 4)}");
            Console.WriteLine($"  UInt16 @ 6: {BitConverter.ToUInt16(data, 6)}");
            Console.WriteLine($"  UInt16 @ 8: {BitConverter.ToUInt16(data, 8)}");
            Console.WriteLine($"  UInt16 @ 10: {BitConverter.ToUInt16(data, 10)}");
            Console.WriteLine($"  UInt16 @ 12: {BitConverter.ToUInt16(data, 12)}");
        }
        
        // Берём ещё пару файлов разного размера
        Console.WriteLine("\n=== Другие BTX файлы: ===");
        var otherBtx = zip.Entries
            .Where(e => e.Name.EndsWith(".btx"))
            .OrderBy(e => e.Length)
            .Take(5)
            .ToArray();
        foreach (var e2 in otherBtx)
        {
            using var es2 = e2.Open();
            using var ms2 = new MemoryStream();
            es2.CopyTo(ms2);
            byte[] d2 = ms2.ToArray();
            string header = string.Join(" ", d2.Take(16).Select(b => b.ToString("X2")));
            int w = d2.Length >= 8 ? BitConverter.ToInt32(d2, 4) : 0;
            int h = d2.Length >= 12 ? BitConverter.ToInt32(d2, 8) : 0;
            Console.WriteLine($"  {e2.Name,-40} {e2.Length,10} bytes  header: {header}  w={w} h={h}");
        }
    }
}
