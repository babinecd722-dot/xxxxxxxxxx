using System;
using System.IO;
using System.IO.Compression;
using System.Linq;
using BpcEditor.Formats;

class Program
{
    static void Main()
    {
        string bpcPath = @"C:\Users\babin\Downloads\br_tex_skins_01.astc.bpc";
        using var zip = ZipFile.OpenRead(bpcPath);

        var entries = zip.Entries.Where(e => e.Name.EndsWith(".btx")).OrderBy(e => e.Name).Take(30).ToList();
        int cleanCount = 0;

        foreach (var entry in entries)
        {
            using var ms = new MemoryStream();
            using (var es = entry.Open()) es.CopyTo(ms);
            var tex = BtxTexture.Load(ms.ToArray());

            if (!AstcDecoder.IsAstcFormat(tex.GlInternalFormat)) { cleanCount++; continue; }
            AstcDecoder.GetBlockSize(tex.GlInternalFormat, out int bw, out int bh);

            byte[] dec = AstcDecoder.Decode(tex.TopMipData, tex.Width, tex.Height, bw, bh);
            int total = 0, bad = 0;
            for (int y = 0; y < tex.Height; y++)
            for (int x = 0; x < tex.Width; x++)
            {
                int i = (y * tex.Width + x) * 4;
                total++;
                if (dec[i]==255 && dec[i+1]==0 && dec[i+2]==255 && dec[i+3]==255) bad++;
            }
            double pct = total > 0 ? 100.0 * bad / total : 0;
            string status = bad == 0 ? "OK" : $"ERR {pct:F1}%";
            Console.WriteLine($"{entry.Name,-30} {tex.Width}x{tex.Height} {status}");
            if (bad == 0) cleanCount++;
        }
        Console.WriteLine($"\nClean: {cleanCount}/{entries.Count}");
    }
}
