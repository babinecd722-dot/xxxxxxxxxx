using System.IO.Compression;

var bpcFiles = Directory.GetFiles(@"C:\Users\babin\Downloads", "*.bpc", SearchOption.AllDirectories)
    .Where(f => !f.Contains("TestData") && !f.Contains("Analyze"))
    .Take(5)
    .ToArray();

string file = bpcFiles[0];
using var fs = File.OpenRead(file);
using var zip = new ZipArchive(fs, ZipArchiveMode.Read);

var btxEntries = zip.Entries
    .Where(e => e.Name.EndsWith(".btx", StringComparison.OrdinalIgnoreCase))
    .OrderBy(e => e.Length)
    .ToArray();

// Анализ KTX формата — берём маленький и большой файл
var samples = new[] { btxEntries.First(), btxEntries.Last(), btxEntries[btxEntries.Length / 2] };

foreach (var btxEntry in samples)
{
    using var es = btxEntry.Open();
    using var ms = new MemoryStream();
    es.CopyTo(ms);
    byte[] d = ms.ToArray();

    Console.WriteLine($"\n=== {btxEntry.FullName} ({d.Length} bytes) ===");
    
    // Кастомный префикс
    int prefix = BitConverter.ToInt32(d, 0);
    Console.WriteLine($"Prefix (first 4 bytes as int32): {prefix}");
    
    // KTX1 header начинается с offset 4
    int off = 4;
    // KTX identifier: 12 bytes
    Console.WriteLine($"KTX magic: {BitConverter.ToString(d, off, 12)}");
    off += 12;
    
    int endianness = BitConverter.ToInt32(d, off); off += 4;
    int glType = BitConverter.ToInt32(d, off); off += 4;
    int glTypeSize = BitConverter.ToInt32(d, off); off += 4;
    int glFormat = BitConverter.ToInt32(d, off); off += 4;
    int glInternalFormat = BitConverter.ToInt32(d, off); off += 4;
    int glBaseInternalFormat = BitConverter.ToInt32(d, off); off += 4;
    int pixelWidth = BitConverter.ToInt32(d, off); off += 4;
    int pixelHeight = BitConverter.ToInt32(d, off); off += 4;
    int pixelDepth = BitConverter.ToInt32(d, off); off += 4;
    int numArrayElements = BitConverter.ToInt32(d, off); off += 4;
    int numFaces = BitConverter.ToInt32(d, off); off += 4;
    int numMipLevels = BitConverter.ToInt32(d, off); off += 4;
    int bytesOfKeyValueData = BitConverter.ToInt32(d, off); off += 4;
    
    Console.WriteLine($"  endianness: 0x{endianness:X8}");
    Console.WriteLine($"  glType: {glType}  glTypeSize: {glTypeSize}");
    Console.WriteLine($"  glFormat: 0x{glFormat:X}  glInternalFormat: 0x{glInternalFormat:X}  glBaseInternalFormat: 0x{glBaseInternalFormat:X}");
    Console.WriteLine($"  pixelWidth: {pixelWidth}  pixelHeight: {pixelHeight}  pixelDepth: {pixelDepth}");
    Console.WriteLine($"  numArrayElements: {numArrayElements}  numFaces: {numFaces}  numMipLevels: {numMipLevels}");
    Console.WriteLine($"  bytesOfKeyValueData: {bytesOfKeyValueData}");
    
    // Пропуск KV данных
    off += bytesOfKeyValueData;
    
    // Mip уровни
    for (int mip = 0; mip < Math.Min(numMipLevels, 3); mip++)
    {
        if (off + 4 > d.Length) break;
        int imageSize = BitConverter.ToInt32(d, off); off += 4;
        Console.WriteLine($"  Mip {mip}: imageSize={imageSize}, offset={off}, remaining={d.Length - off}");
        off += imageSize;
        // Выравнивание до 4 байт
        off = (off + 3) & ~3;
    }
    
    // Определяем формат ASTC
    string astcName = glInternalFormat switch
    {
        0x93B0 => "ASTC_4x4",
        0x93B1 => "ASTC_5x4",
        0x93B2 => "ASTC_5x5",
        0x93B3 => "ASTC_6x5",
        0x93B4 => "ASTC_6x6",
        0x93B5 => "ASTC_8x5",
        0x93B6 => "ASTC_8x6",
        0x93B7 => "ASTC_8x8",
        0x93B8 => "ASTC_10x5",
        0x93B9 => "ASTC_10x6",
        0x93BA => "ASTC_10x8",
        0x93BB => "ASTC_10x10",
        0x93BC => "ASTC_12x10",
        0x93BD => "ASTC_12x12",
        0x93D0 => "ASTC_4x4_SRGB",
        0x93D4 => "ASTC_6x6_SRGB",
        _ => $"UNKNOWN_0x{glInternalFormat:X}"
    };
    Console.WriteLine($"  ASTC Format: {astcName}");
}
