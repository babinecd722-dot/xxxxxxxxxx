using System;
using System.IO;
using System.IO.Compression;

string bpcPath = null;
foreach (var f in Directory.GetFiles(@"C:\Users\babin\Downloads", "*.bpc"))
{ bpcPath = f; break; }
if (bpcPath == null) foreach (var f in Directory.GetFiles(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "*.bpc"))
{ bpcPath = f; break; }
if (bpcPath == null) foreach (var f in Directory.GetFiles(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "*.bpc"))
{ bpcPath = f; break; }

// Also try current dir and parent
if (bpcPath == null) foreach (var f in Directory.GetFiles(@"C:\Users\babin\Downloads\jj", "*.bpc", SearchOption.AllDirectories))
{ bpcPath = f; break; }

if (bpcPath == null) { Console.WriteLine("No .bpc file found!"); return; }
Console.WriteLine($"Found: {bpcPath}");

byte[] ktxMagic = { 0xAB, 0x4B, 0x54, 0x58, 0x20, 0x31, 0x31, 0xBB, 0x0D, 0x0A, 0x1A, 0x0A };

using var zip = ZipFile.OpenRead(bpcPath);
int count = 0;
foreach (var entry in zip.Entries)
{
    if (!entry.Name.EndsWith(".btx", StringComparison.OrdinalIgnoreCase)) continue;
    if (count++ >= 5) break;

    using var ms = new MemoryStream();
    using (var s = entry.Open()) s.CopyTo(ms);
    byte[] data = ms.ToArray();
    
    Console.WriteLine($"\n=== {entry.Name} ({data.Length} bytes) ===");
    Console.Write("First 80 bytes hex: ");
    for (int i = 0; i < Math.Min(80, data.Length); i++) Console.Write($"{data[i]:X2} ");
    Console.WriteLine();
    
    // Find KTX magic
    int off = -1;
    if (data.Length >= 16 && data[4] == 0xAB && data[5] == 0x4B) off = 4;
    else if (data.Length >= 12 && data[0] == 0xAB && data[1] == 0x4B) off = 0;
    
    if (off >= 0)
    {
        int p = off + 12; // after magic
        int endian = BitConverter.ToInt32(data, p); p += 4;
        Console.WriteLine($"Endianness: 0x{endian:X8} ({(endian == 0x04030201 ? "LE" : "BE")})");
        int glType = BitConverter.ToInt32(data, p); p += 4;
        int glTypeSize = BitConverter.ToInt32(data, p); p += 4;
        int glFormat = BitConverter.ToInt32(data, p); p += 4;
        int glInternalFmt = BitConverter.ToInt32(data, p); p += 4;
        int glBaseFmt = BitConverter.ToInt32(data, p); p += 4;
        int w = BitConverter.ToInt32(data, p); p += 4;
        int h = BitConverter.ToInt32(data, p); p += 4;
        int depth = BitConverter.ToInt32(data, p); p += 4;
        int arrElem = BitConverter.ToInt32(data, p); p += 4;
        int faces = BitConverter.ToInt32(data, p); p += 4;
        int mips = BitConverter.ToInt32(data, p); p += 4;
        int kvBytes = BitConverter.ToInt32(data, p); p += 4;
        Console.WriteLine($"glType=0x{glType:X4} glTypeSize={glTypeSize} glFormat=0x{glFormat:X4}");
        Console.WriteLine($"glInternalFormat=0x{glInternalFmt:X4} glBaseInternalFormat=0x{glBaseFmt:X4}");
        Console.WriteLine($"Size: {w}x{h} depth={depth} arrays={arrElem} faces={faces} mips={mips} kvBytes={kvBytes}");
        
        if (glType == 0) Console.WriteLine("*** COMPRESSED TEXTURE (glType=0) ***");
    }
}
